<?php

class Blog extends CI_Controller
{
    public function  __construct()
    {
        parent::__construct();
    }

    public function Index()
    {
        // Menu
        $this->load->model("crud");
        $data['itens_menu'] = $this->crud->select("menu");

        $data['titulo'] = "Blog";
        $data['pagina'] = "blog";
        $this->load->view("layout", $data);
    }
}

?>
