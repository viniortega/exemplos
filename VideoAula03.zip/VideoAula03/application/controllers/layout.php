<?php

class Layout extends CI_Controller
{
    public function  __construct()
    {
        parent::__construct();
    }

    public function Index()
    {
        // Menu
        $this->load->model("crud");
        $data['itens_menu'] = $this->crud->select("menu");
        
        $data['pagina'] = "inicio";
        $data['titulo'] = "Principal";
        $this->load->view("layout", $data);
    }
}

?>
