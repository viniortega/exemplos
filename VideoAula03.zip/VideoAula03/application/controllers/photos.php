<?php

class Photos extends CI_Controller
{
    public function  __construct()
    {
        parent::__construct();
    }

    public function Index()
    {
        // Menu
        $this->load->model("crud");
        $data['itens_menu'] = $this->crud->select("menu");

        $data['titulo'] = "Galeria de Fotos";
        $data['pagina'] = "photos";
        $this->load->view("layout", $data);
    }
}

?>
