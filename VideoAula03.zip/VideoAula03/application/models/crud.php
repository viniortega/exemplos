<?php
class Crud extends CI_Model
{
	// Inserir
	public function Insert($tabela, $dados)
	{
		$this->db->insert($tabela, $dados);
		return $this->db->insert_id();
	}

	// Select simples
	public function Select($tabela, $dados = array())
	{

		$key 	= @array_keys($dados);
		$value	= @array_values($dados);
                if (isset($dados))
                {
                    $query = $this->db->query ("SELECT * FROM $tabela");
                }
                else
                {
                    $query = $this->db->query ("SELECT * FROM $tabela WHERE $key[0] = '$value[0]'");
                }
		
		return $query->result();
	}

        // Update
	public function Update($tabela, $dados, $condicao, $fields = 'id')
	{
		$this->db->where($fields, $condicao);
		$retorno = $this->db->update($tabela, $dados);
		return $retorno;
	}

        // Delete
	public function Delete($tabela, $id)
	{
		$query = $this->db->delete($tabela, $id);
		return $query;
	}
}