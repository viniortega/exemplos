<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Layout extends MX_Controller
{

    public function index()
    {

        $this->load->model("crud");
        
        $onde = array(
            //"usuario"=>"luizpicolo"
        );

        $ordem = array(
            "id" => "asc"
        );

        $limite = array(        
            "2"=>"0"
        );

        $data["dados"] = $this->crud->selecionar("usuario", $onde, $ordem, $limite);

        $this->load->view('layout', $data);
    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */