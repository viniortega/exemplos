<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Crud com Codeigniter</title>
</head>
<body>

<div id="container">
	<?php 
            foreach ($dados as $dado)
            {
                echo $dado->usuario;
                echo "<br />";
            }
        ?>
</div>

</body>
</html>