<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Crud extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function Selecionar($tabela = "", $onde = array(), $ordem = array(), $limite = array())
    {
        if (!$tabela)
        {
            echo utf8_decode("<p align='center'>É necessário indicar uma tabela para a seleção</p>");          
            exit;
        }
        
        if ($onde)
        {
            $this->db->where($onde);
        }
        
        if ($ordem)
        {
            foreach ($ordem as $key=>$value)
            {
                $this->db->order_by($key, $value);
            }
            
        }
        
        if ($limite)
        {
            foreach ($limite as $key=>$value)
            {
                $this->db->limit($key, $value);
            }
            
        }

        $dados = $this->db->get($tabela);
        return $dados->result();
        
    }

}

?>
