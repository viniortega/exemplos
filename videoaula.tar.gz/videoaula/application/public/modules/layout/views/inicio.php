<div class="post">
    <h2 class="title"><a href="#">Welcome to Lepidoptera
        </a></h2>
    <p class="meta"><span class="date">May 28, 2011</span><span class="posted">Posted by <a href="#">Someone</a></span></p>
    <div style="clear: both;">&nbsp;</div>
    <div class="entry">
        <p>This is <strong>Lepidoptera
            </strong>, a free, fully standards-compliant CSS template designed by FreeCssTemplates<a href="http://www.nodethirtythree.com/"></a> for <a href="http://www.freecsstemplates.org/">Free CSS Templates</a>.  This free template is released under a <a href="http://creativecommons.org/licenses/by/3.0/">Creative Commons Attribution 3.0</a> license, so you’re pretty much free to do whatever you want with it (even use it commercially) provided you keep the links in the footer intact. Aside from that, have fun with it :)</p>
        <p>Sed lacus. Donec lectus. Nullam pretium nibh ut turpis. Nam bibendum. In nulla tortor, elementum ipsum. Proin imperdiet est. Phasellus dapibus semper urna. Pellentesque ornare, orci in felis. Donec ut ante. In id eros. Suspendisse lacus turpis, cursus egestas at sem.</p>
        <p class="links"><a href="#" class="more">Read More</a><a href="#" title="b0x" class="comments">Comments</a></p>
    </div>
</div>
<div class="post">
    <h2 class="title"><a href="#">Lorem ipsum sed aliquam</a></h2>
    <p class="meta"><span class="date">May 20, 2011</span><span class="posted">Posted by <a href="#">Someone</a></span></p>
    <div style="clear: both;">&nbsp;</div>
    <div class="entry">
        <p>Sed lacus. Donec lectus. Nullam pretium nibh ut turpis. Nam bibendum. In nulla tortor, elementum vel, tempor at, varius non, purus. Mauris vitae nisl nec metus placerat consectetuer. Donec ipsum. Proin imperdiet est. Phasellus <a href="#">dapibus semper urna</a>. Pellentesque ornare, orci in consectetuer hendrerit, urna elit eleifend nunc, ut consectetuer nisl felis ac diam. Etiam non felis. Donec ut ante. In id eros. Suspendisse lacus turpis, cursus egestas at sem.  Mauris quam enim, molestie in, rhoncus ut, lobortis a, est.</p>
        <p class="links"><a href="#" class="more">Read More</a><a href="#" title="b0x" class="comments">Comments</a></p>
    </div>
</div>
<div class="post">
    <h2 class="title"><a href="#">Consecteteur hendrerit </a></h2>
    <p class="meta"><span class="date">May 10, 2011</span><span class="posted">Posted by <a href="#">Someone</a></span></p>
    <div style="clear: both;">&nbsp;</div>
    <div class="entry">
        <p>Sed lacus. Donec lectus. Nullam pretium nibh ut turpis. Nam bibendum. In nulla tortor, elementum vel, tempor at, varius non, purus. Mauris vitae nisl nec metus placerat consectetuer. Donec ipsum. Proin imperdiet est. Phasellus <a href="#">dapibus semper urna</a>. Pellentesque ornare, orci in consectetuer hendrerit, urna elit eleifend nunc, ut consectetuer nisl felis ac diam. Etiam non felis. Donec ut ante. In id eros. Suspendisse lacus turpis, cursus egestas at sem.  Mauris quam enim, molestie in, rhoncus ut, lobortis a, est.</p>
        <p class="links"><a href="#" class="more">Read More</a><a href="#" title="b0x" class="comments">Comments</a></p>
    </div>
</div>
<div style="clear: both;">&nbsp;</div>