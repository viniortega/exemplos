<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Name       : Lepidoptera
   
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20110329

-->
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <base href="<?php echo base_url(); ?>" />
        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title>Lepidoptera
            by Free CSS Templates</title>
        <link href="<?php echo $base ?>css/style.css" rel="stylesheet" type="text/css" media="screen" />
    </head>
    <body>
        <div id="wrapper">
            <div id="header" class="container">
                <div id="logo">
                    <h1><a href="#">Lepidoptera
                        </a></h1>
                    <p>template design by <a href="http://www.freecsstemplates.org/">Free CSS Templates</a></p>
                </div>
                <div id="menu">
                    <ul>
                        <li class="current_page_item"><a href="index.php">Homepage</a></li>
                        <li><a href="blog">Blog</a></li>
                        <li><a href="photos">Photos</a></li>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Links</a></li>
                        <li><a href="#">Contact</a></li>
                    </ul>
                </div>
            </div>
            <!-- end #header -->
            <div id="splash" class="container"><img src="<?php echo $base ?>images/img02.jpg" width="1000" height="300" alt="" /></div>
            <div id="page" class="container">
                <div id="marketing">
                    <p class="text1">In posuere eleifend odio quisque semperula</p>
                    <p class="text2"><a href="#">View Details</a></p>
                </div>
                <div id="content">
                    <?php $this->load->view($pagina)?>
                </div>
                <!-- end #content -->
                <div id="sidebar">
                    <ul>
                        <li>
                            <div id="search" >
                                <form method="get" action="#">
                                    <div>
                                        <input type="text" name="s" id="search-text" value="" />
                                        <input type="submit" id="search-submit" value="GO" />
                                    </div>
                                </form>
                            </div>
                            <div style="clear: both;">&nbsp;</div>
                        </li>
                        <li>
                            <h2>Aliquam tempus</h2>
                            <p>Mauris vitae nisl nec metus placerat perdiet est. Phasellus dapibus semper consectetuer hendrerit.</p>
                        </li>
                        <li>
                            <h2>Categories</h2>
                            <ul>
                                <li><a href="#">Aliquam libero</a></li>
                                <li><a href="#">Consectetuer adipiscing elit</a></li>
                                <li><a href="#">Metus aliquam pellentesque</a></li>
                                <li><a href="#">Suspendisse iaculis mauris</a></li>
                                <li><a href="#">Urnanet non molestie semper</a></li>
                                <li><a href="#">Proin gravida orci porttitor</a></li>
                            </ul>
                        </li>
                        <li>
                            <h2>Blogroll</h2>
                            <ul>
                                <li><a href="#">Aliquam libero</a></li>
                                <li><a href="#">Consectetuer adipiscing elit</a></li>
                                <li><a href="#">Metus aliquam pellentesque</a></li>
                                <li><a href="#">Suspendisse iaculis mauris</a></li>
                                <li><a href="#">Urnanet non molestie semper</a></li>
                                <li><a href="#">Proin gravida orci porttitor</a></li>
                            </ul>
                        </li>
                        <li>
                            <h2>Archives</h2>
                            <ul>
                                <li><a href="#">Aliquam libero</a></li>
                                <li><a href="#">Consectetuer adipiscing elit</a></li>
                                <li><a href="#">Metus aliquam pellentesque</a></li>
                                <li><a href="#">Suspendisse iaculis mauris</a></li>
                                <li><a href="#">Urnanet non molestie semper</a></li>
                                <li><a href="#">Proin gravida orci porttitor</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <!-- end #sidebar -->
                <div style="clear: both;">&nbsp;</div>
            </div>
            <!-- end #page -->
        </div>
        <div id="footer-content" class="container">
            <div id="footer-bg">
                <div id="column1">
                    <h2>Welcome to my website</h2>
                    <p>In posuere eleifend odio quisque semper augue mattis wisi maecenas ligula. Donec leo, vivamus fermentum nibh in augue praesent a lacus at urna congue rutrum. Quisque dictum integer nisl risus, sagittis convallis, rutrum id, congue, and nibh.</p>
                </div>
                <div id="column2">
                    <h2>Etiam rhoncus volutpat</h2>
                    <p>Sed lacus. Donec lectus. Nullam pretium nibh ut turpis. Nam bibendum. In nulla tortor, elementum vel, tempor at, varius non, purus. Mauris vitae nisl nec metus consectetuer. Donec ipsum. Proin imperdiet est. Phasellus dapibus semper urna.</p>
                </div>
                <div id="column3">
                    <h2>Recommended Links</h2>
                    <ul>
                        <li><a href="#">Consectetuer adipiscing elit</a></li>
                        <li><a href="#">Metus aliquam pellentesque</a></li>
                        <li><a href="#">Suspendisse iaculis mauris</a></li>
                        <li><a href="#">Urnanet non molestie semper</a></li>
                        <li><a href="#">Proin gravida orci porttitor</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div id="footer">
            <p>Copyright (c) 2008 Sitename.com. All rights reserved. Design by <a href="http://www.freecsstemplates.org/">Free CSS Templates</a>.</p>
        </div>
        <!-- end #footer -->
    </body>
</html>
